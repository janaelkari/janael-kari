import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class MenuBar extends JFrame implements ActionListener{
	JButton button1;
	
	JMenuItem m11 = new JMenuItem();
	JMenuItem m12 = new JMenuItem();
	JPanel jp = new JPanel();
	JLabel label = new JLabel("enter text");
	JTextField jt = new JTextField(20);
	JButton button2;
public MenuBar(String s) {
	button1.setText("send");
	button2.setText("resend");
	JMenuBar mb = new JMenuBar();
	this.setJMenuBar(mb);
	JMenu m1 = new JMenu("FILE");
	mb.add(m1);
	JMenuItem m11 = new JMenuItem("Open");
	m1.add(m11);
	this.setJMenuBar(mb);
	
	jp.setLayout(new FlowLayout());
	jp.setBackground(Color.white);
	jp.add(label);
	jp.add(button1);
	jp.add(button2);
	jp.add(jt);
	this.getContentPane().add(BorderLayout.SOUTH);
	button1.addActionListener((ActionListener) this);
	button2.addActionListener((ActionListener) this);
	m11.addActionListener((ActionListener) this);
	m12.addActionListener((ActionListener) this);
	
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setSize(500,500);
	
	@Override
	public void actionPerformed(ActionEvent e) {
	JButton b = (JButton) e.getSource();
	if (b==button1)
	{
	JOptionPane.showConfirmDialog(this, "You clicked Button1","Button Click Event Handler", JOptionPane.PLAIN_MESSAGE);
	}else if (b==button2)
	{
	JOptionPane.showConfirmDialog(this, "You clicked Button2","Button Click Event Handler",
	JOptionPane.PLAIN_MESSAGE);
	}
	}
}