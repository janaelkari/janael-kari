import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
		
		
public class MyFrame extends JFrame implements ActionListener{
	JButton button1 = new JButton();
	JButton button2 = new JButton();
		public MyFrame(String title) throws HeadlessException {
			super(title);
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.setSize(300,300);
			this.getContentPane().setLayout(new FlowLayout());
			button1 = new JButton("Press");
		this.getContentPane().add(button1);
		button1.setText("Click Me");
		button1.setToolTipText("Press me and watch what happens");
		button2 = new JButton("Button 2");
		this.getContentPane().add(button2);
		//button1.setText("Press Me");
		//button1.setToolTipText("Press me and watch what happens");
		//cursor = new 
		this.getContentPane().add(BorderLayout.NORTH,button1);
		this.getContentPane().add(BorderLayout.SOUTH,button2);
		
		this.getContentPane().setLayout(new FlowLayout());
		button1.addActionListener(this);
		button2.addActionListener(this);
		this.setVisible(true);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
		JButton b = (JButton) e.getSource();
		if (b==button1)
		{
		JOptionPane.showConfirmDialog(this, "You clicked Button1","Button Click Event Handler", JOptionPane.PLAIN_MESSAGE);
		}else if (b==button2)
		{
		JOptionPane.showConfirmDialog(this, "You clicked Button2","Button Click Event Handler",
		JOptionPane.PLAIN_MESSAGE);
		}
		}

		
		
}
