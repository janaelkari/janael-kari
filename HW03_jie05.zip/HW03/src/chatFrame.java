import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class chatFrame extends JFrame implements ActionListener{
	JMenuItem m11;
	JMenuItem m12;
	JMenuItem m111;
	
	public chatFrame(String title) throws HeadlessException {
		super(title);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(300,300);
		
		this.getContentPane().setLayout(new FlowLayout());
		JMenuBar mb =new JMenuBar();
		JMenu m1 = (JMenu) new JMenuItem("FILE");
		mb.add(m1);
		JMenu m11 = (JMenu) new JMenuItem("opne");
		mb.add(m11);
		JMenu m111 = (JMenu) new JMenuItem("save as");
		mb.add(m111);
		
		JMenu m2 = (JMenu) new JMenuItem("help");
		mb.add(m2);
		this.setJMenuBar(mb);
		this.setVisible(true);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	}
	
}
